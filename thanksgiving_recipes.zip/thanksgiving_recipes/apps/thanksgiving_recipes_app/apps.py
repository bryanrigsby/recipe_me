from django.apps import AppConfig


class ThanksgivingRecipesAppConfig(AppConfig):
    name = 'thanksgiving_recipes_app'
